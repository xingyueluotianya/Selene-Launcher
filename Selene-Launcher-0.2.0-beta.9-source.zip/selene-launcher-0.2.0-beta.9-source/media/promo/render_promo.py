#!/usr/bin/env python3
"""Render the Selene Launcher high-motion vector promotion film with FFmpeg.

All key art is authored as editable SVG. FFmpeg turns those compositions into
an energetic motion-design film with spring entrances, parallax cameras,
chromatic impact frames, HUD sweeps, technology transitions, and an original
rhythmic sound design bed. No external media or Python package is required.
"""
from __future__ import annotations

import json
import shutil
import subprocess
import sys
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MEDIA = ROOT / "media" / "promo"
VECTORS = MEDIA / "vectors"
RENDERED = MEDIA / "rendered"
DIST = ROOT / "dist"
VIDEO = DIST / "Selene-Launcher-Promo-AE-Motion-72s.mp4"
BUNDLE = DIST / "Selene-Launcher-Promo-AE-Motion-Package.zip"
W, H, FPS = 1920, 1080, 30
CLIP_DURATION = 7.25
TRANSITION = 0.72
FONT = "DejaVu Sans"
MOTION_STYLE = "AE-inspired kinetic vector · spring physics · tech impact transitions"

STORYBOARD = [
    {"id": "01-awaken", "time": "00:00–00:07", "title": "YOUR WORLD. ONE LAUNCH.", "copy": "Meet Selene Launcher"},
    {"id": "02-command-center", "time": "00:07–00:14", "title": "EVERYTHING. IN ONE PLACE.", "copy": "A focused command center for Minecraft Java Edition"},
    {"id": "03-install", "time": "00:14–00:21", "title": "FROM VERSION TO PLAYABLE.", "copy": "Client. Libraries. Assets. Java. Verified automatically."},
    {"id": "04-loaders", "time": "00:21–00:28", "title": "CHOOSE YOUR WAY TO PLAY.", "copy": "Vanilla · Fabric · Forge · NeoForge"},
    {"id": "05-resources", "time": "00:28–00:35", "title": "DISCOVER WHAT'S NEXT.", "copy": "Rich Modrinth previews, compatibility and one-click installs"},
    {"id": "06-modpacks", "time": "00:35–00:42", "title": "DROP IT. SELENE BUILDS IT.", "copy": "Drag in .mrpack or .zip and let the safe importer work"},
    {"id": "07-identity", "time": "00:42–00:49", "title": "PLAY AS YOU.", "copy": "Microsoft · LittleSkin · Yggdrasil · Offline"},
    {"id": "08-downloads", "time": "00:49–00:56", "title": "PAUSE. RESUME. RECOVER.", "copy": "A persistent verified download queue that remembers"},
    {"id": "09-visual", "time": "00:56–01:03", "title": "MAKE THE LAUNCHER YOURS.", "copy": "Selene Shader Graph · live visual presets across the app"},
    {"id": "10-control", "time": "01:03–01:10", "title": "YOUR SPACE. YOUR RULES.", "copy": "Custom drives, managed Java, clear logs and diagnostics"},
    {"id": "11-finale", "time": "01:10–01:12", "title": "SELENE LAUNCHER", "copy": "Less setup. More world."},
]


def run(command: list[str]) -> None:
    print("+", " ".join(command))
    subprocess.run(command, cwd=ROOT, check=True)


def esc(value: str) -> str:
    return (value.replace("&", "&amp;").replace("<", "&lt;")
            .replace(">", "&gt;").replace('"', "&quot;"))


def pill(x: int, y: int, text: str, color: str = "#9B86FF", width: int | None = None) -> str:
    width = width or max(140, 34 + len(text) * 17)
    return f'''<g><rect x="{x}" y="{y}" width="{width}" height="44" rx="22" fill="{color}" fill-opacity=".14" stroke="{color}" stroke-opacity=".48"/>
    <text x="{x + width / 2}" y="{y + 29}" text-anchor="middle" class="pill" fill="{color}">{esc(text)}</text></g>'''


def card(x: int, y: int, w: int, h: int, title: str = "", copy: str = "", accent: str = "#9B86FF", extra: str = "") -> str:
    return f'''<g><rect x="{x}" y="{y}" width="{w}" height="{h}" rx="32" class="glass"/>
    <rect x="{x + 1}" y="{y + 1}" width="{w - 2}" height="{h - 2}" rx="31" fill="none" stroke="{accent}" stroke-opacity=".22"/>
    <circle cx="{x + 39}" cy="{y + 42}" r="8" fill="{accent}"/><text x="{x + 62}" y="{y + 49}" class="card-title">{esc(title)}</text>
    <text x="{x + 38}" y="{y + 87}" class="card-copy">{esc(copy)}</text>{extra}</g>'''


def moon_logo(cx: int, cy: int, size: int) -> str:
    r = size / 2
    return f'''<g filter="url(#glow)">
    <circle cx="{cx}" cy="{cy}" r="{r}" fill="url(#brand)"/>
    <circle cx="{cx + r * .30}" cy="{cy - r * .14}" r="{r * .78}" fill="#0B0D19"/>
    <circle cx="{cx - r * .47}" cy="{cy + r * .30}" r="{r * .10}" fill="#5EE6FF"/>
    </g>'''


def base(scene: dict, body: str, index: int, dark: str = "#090A14") -> str:
    progress = int((index + 1) / len(STORYBOARD) * 1680)
    stars = "".join(
        f'<circle cx="{(i * 173 + index * 71) % 1880 + 20}" cy="{(i * 97 + index * 43) % 980 + 20}" r="{1 + i % 3 * .45}" fill="#C7D2FE" opacity="{.08 + (i % 5) * .035}"/>'
        for i in range(34)
    )
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{W}" height="{H}" viewBox="0 0 {W} {H}">
<defs>
  <linearGradient id="bg" x1="0" y1="0" x2="1" y2="1"><stop stop-color="{dark}"/><stop offset=".56" stop-color="#11132A"/><stop offset="1" stop-color="#080A13"/></linearGradient>
  <linearGradient id="brand" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#5EE6FF"/><stop offset=".48" stop-color="#9B86FF"/><stop offset="1" stop-color="#FF5FD2"/></linearGradient>
  <linearGradient id="warm" x1="0" y1="0" x2="1" y2="1"><stop stop-color="#FFBE66"/><stop offset="1" stop-color="#FF5FD2"/></linearGradient>
  <radialGradient id="halo"><stop stop-color="#9B86FF" stop-opacity=".32"/><stop offset="1" stop-color="#9B86FF" stop-opacity="0"/></radialGradient>
  <filter id="glow" x="-80%" y="-80%" width="260%" height="260%"><feGaussianBlur stdDeviation="18" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
  <filter id="shadow" x="-20%" y="-30%" width="140%" height="170%"><feDropShadow dx="0" dy="22" stdDeviation="28" flood-color="#000" flood-opacity=".38"/></filter>
  <style>
    text{{font-family:'{FONT}',sans-serif;letter-spacing:.02em}} .kicker{{font-size:20px;font-weight:700;letter-spacing:.28em;fill:#A8B0D4}}
    .hero{{font-size:76px;font-weight:700;letter-spacing:-.025em;fill:#F8FAFF}} .copy{{font-size:28px;fill:#AAB2D3}}
    .card-title{{font-size:23px;font-weight:700;fill:#F8FAFF}} .card-copy{{font-size:17px;fill:#9099BC}}
    .tiny{{font-size:15px;fill:#7F89AE}} .pill{{font-size:15px;font-weight:700;letter-spacing:.08em}}
    .glass{{fill:#15182A;fill-opacity:.88;stroke:#FFFFFF;stroke-opacity:.09}}
  </style>
</defs>
<rect width="1920" height="1080" fill="url(#bg)"/><ellipse cx="1480" cy="180" rx="600" ry="480" fill="url(#halo)" opacity=".65"/>{stars}
<g><text x="120" y="90" class="kicker">SELENE LAUNCHER</text><text x="1800" y="90" text-anchor="end" class="tiny">{esc(scene['time'])}</text></g>
{body}
<g><rect x="120" y="1022" width="1680" height="2" rx="1" fill="#303655"/><rect x="120" y="1022" width="{progress}" height="3" rx="2" fill="url(#brand)"/></g>
</svg>'''


def scene_heading(title: str, copy: str, y: int = 210, center: bool = False) -> str:
    x, anchor = (960, "middle") if center else (120, "start")
    return f'''<g><text x="{x}" y="{y}" text-anchor="{anchor}" class="hero">{esc(title)}</text>
    <text x="{x}" y="{y + 48}" text-anchor="{anchor}" class="copy">{esc(copy)}</text></g>'''


def scenes() -> list[tuple[str, str]]:
    result: list[tuple[str, str]] = []

    s = STORYBOARD[0]
    body = f'''<ellipse cx="960" cy="540" rx="520" ry="420" fill="url(#halo)"/>{moon_logo(960, 480, 310)}
    <text x="960" y="730" text-anchor="middle" class="hero" font-size="96">SELENE LAUNCHER</text>
    <text x="960" y="786" text-anchor="middle" class="copy">YOUR WORLD. ONE LAUNCH.</text>
    <path d="M760 845 H1160" stroke="url(#brand)" stroke-width="3" stroke-linecap="round"/>'''
    result.append((s["id"], base(s, body, 0)))

    s = STORYBOARD[1]
    sidebar = '''<rect x="246" y="354" width="210" height="468" rx="22" fill="#0E1020"/><circle cx="292" cy="402" r="17" fill="url(#brand)"/>
    <text x="324" y="410" class="card-title" font-size="19">Selene</text>'''
    for i, label in enumerate(["Overview", "Library", "Resources", "Downloads", "Visual Lab"]):
        yy = 478 + i * 63
        selected = i == 0
        sidebar += f'<rect x="268" y="{yy - 29}" width="166" height="44" rx="13" fill="{"#26213F" if selected else "#121527"}"/><circle cx="293" cy="{yy - 7}" r="5" fill="{"#9B86FF" if selected else "#515A7C"}"/><text x="312" y="{yy}" class="tiny" fill="{"#F8FAFF" if selected else "#7F89AE"}">{label}</text>'
    window = f'''<g><rect x="220" y="316" width="1480" height="560" rx="40" class="glass"/>
    <circle cx="266" cy="345" r="6" fill="#FF6B7A"/><circle cx="288" cy="345" r="6" fill="#FFBE66"/><circle cx="310" cy="345" r="6" fill="#51E1A5"/>{sidebar}
    <text x="508" y="410" class="kicker">GOOD EVENING, TRAVELER</text><text x="508" y="474" class="hero" font-size="51">Your next world is ready.</text>
    <rect x="508" y="523" width="1100" height="228" rx="28" fill="#181B31" stroke="#9B86FF" stroke-opacity=".35"/>
    <text x="552" y="580" class="pill" fill="#9B86FF">JAVA EDITION</text><text x="552" y="640" class="card-title" font-size="35">Install your first game instance</text>
    <text x="552" y="682" class="card-copy" font-size="20">Versions, accounts, resources and visual themes — composed.</text>
    <rect x="552" y="704" width="184" height="48" rx="24" fill="url(#brand)"/><text x="644" y="735" text-anchor="middle" class="pill" fill="#080A14">INSTALL GAME</text></g>'''
    result.append((s["id"], base(s, scene_heading(s["title"], s["copy"], 196) + window, 1)))

    s = STORYBOARD[2]
    steps = [("01", "VERSION", "Official metadata", "#5EE6FF"), ("02", "LIBRARIES", "Shared & verified", "#9B86FF"), ("03", "ASSETS", "Resumable batches", "#FF5FD2"), ("04", "JAVA", "Right runtime", "#51E1A5")]
    pipeline = '<path d="M300 610 H1620" stroke="#353B5B" stroke-width="5" stroke-linecap="round"/>'
    for i, (n, title, copy, color) in enumerate(steps):
        x = 300 + i * 440
        pipeline += f'''<g><circle cx="{x}" cy="610" r="82" fill="#13162A" stroke="{color}" stroke-width="3"/><circle cx="{x}" cy="610" r="58" fill="{color}" fill-opacity=".13"/>
        <text x="{x}" y="621" text-anchor="middle" class="hero" font-size="37" fill="{color}">{esc(n)}</text><text x="{x}" y="735" text-anchor="middle" class="card-title">{esc(title)}</text><text x="{x}" y="768" text-anchor="middle" class="card-copy">{esc(copy)}</text></g>'''
    result.append((s["id"], base(s, scene_heading(s["title"], s["copy"], 220, True) + pipeline + pill(820, 855, "SHA VERIFIED", "#51E1A5", 280), 2)))

    s = STORYBOARD[3]
    loaders = [("V", "VANILLA", "Pure release", "#5EE6FF"), ("F", "FABRIC", "Fast & lightweight", "#9B86FF"), ("F", "FORGE", "The classic ecosystem", "#FFBE66"), ("N", "NEOFORGE", "Modern modding", "#51E1A5")]
    body = scene_heading(s["title"], s["copy"], 214, True)
    for i, (letter, title, copy, color) in enumerate(loaders):
        x = 170 + i * 410
        extra = f'''<circle cx="{x + 155}" cy="{500}" r="54" fill="{color}" fill-opacity=".14" stroke="{color}" stroke-width="2"/><text x="{x + 155}" y="518" text-anchor="middle" class="hero" font-size="49" fill="{color}">{letter}</text>
        <rect x="{x + 55}" y="650" width="200" height="46" rx="23" fill="{color}" fill-opacity=".14"/><text x="{x + 155}" y="679" text-anchor="middle" class="pill" fill="{color}">CLICK TO SELECT</text>'''
        body += card(x, 410, 310, 350, title, copy, color, extra)
    result.append((s["id"], base(s, body, 3)))

    s = STORYBOARD[4]
    body = scene_heading(s["title"], s["copy"], 180)
    body += '''<g><rect x="120" y="300" width="1680" height="580" rx="38" class="glass"/>
    <rect x="164" y="344" width="1050" height="62" rx="21" fill="#0E1121" stroke="#FFFFFF" stroke-opacity=".08"/><text x="204" y="384" class="card-copy" font-size="21">Search mods, shaders, resource packs...</text>
    <rect x="1245" y="344" width="510" height="62" rx="21" fill="#201C38"/><text x="1500" y="384" text-anchor="middle" class="pill" fill="#CBBEFF">MINECRAFT 1.21.1 · FABRIC</text>'''
    resources = [("S", "Sodium", "Performance renderer", "28.6M", "#9B86FF"), ("I", "Iris Shaders", "Beautiful shader support", "17.9M", "#5EE6FF"), ("M", "Modern UI", "Polished interface", "4.2M", "#FF5FD2")]
    for i, (letter, name, desc, dl, color) in enumerate(resources):
        y = 452 + i * 132
        body += f'''<rect x="164" y="{y}" width="1590" height="108" rx="24" fill="#121527" stroke="#FFFFFF" stroke-opacity=".06"/><rect x="188" y="{y + 18}" width="72" height="72" rx="20" fill="{color}" fill-opacity=".18"/><text x="224" y="{y + 67}" text-anchor="middle" class="card-title" font-size="34" fill="{color}">{letter}</text>
        <text x="290" y="{y + 45}" class="card-title">{name}</text><text x="290" y="{y + 76}" class="card-copy">{desc}</text><text x="1320" y="{y + 48}" class="tiny">COMPATIBLE</text><text x="1320" y="{y + 76}" class="card-copy">↓ {dl}</text><rect x="1575" y="{y + 28}" width="140" height="52" rx="26" fill="{color}"/><text x="1645" y="{y + 61}" text-anchor="middle" class="pill" fill="#090A14">INSTALL</text>'''
    body += '</g>'
    result.append((s["id"], base(s, body, 4)))

    s = STORYBOARD[5]
    body = scene_heading(s["title"], s["copy"], 206, True)
    body += f'''<g transform="rotate(-7 560 600)"><rect x="330" y="430" width="460" height="340" rx="38" fill="#171A2D" stroke="#5EE6FF" stroke-opacity=".45"/>
    <path d="M410 520 H575 L640 585 H710 V700 H410 Z" fill="#5EE6FF" fill-opacity=".12" stroke="#5EE6FF" stroke-width="3"/><text x="560" y="650" text-anchor="middle" class="hero" font-size="42">.MRPACK</text></g>
    <path d="M830 595 C925 515 995 515 1090 595" fill="none" stroke="url(#brand)" stroke-width="7" stroke-linecap="round" stroke-dasharray="16 20"/>
    <path d="M1066 568 L1098 596 L1065 621" fill="none" stroke="#FF5FD2" stroke-width="7" stroke-linecap="round" stroke-linejoin="round"/>
    <g filter="url(#glow)"><circle cx="1390" cy="600" r="180" fill="none" stroke="url(#brand)" stroke-width="9"/><circle cx="1390" cy="600" r="138" fill="#15182A"/><path d="M1328 598 L1374 644 L1465 547" fill="none" stroke="#51E1A5" stroke-width="17" stroke-linecap="round" stroke-linejoin="round"/></g>
    {pill(1220, 820, 'SAFE IMPORT COMPLETE', '#51E1A5', 340)}'''
    result.append((s["id"], base(s, body, 5)))

    s = STORYBOARD[6]
    body = scene_heading(s["title"], s["copy"], 210, True)
    accounts = [("M", "MICROSOFT", "Device code OAuth", "#5EE6FF"), ("L", "LITTLESKIN", "Yggdrasil ready", "#FF5FD2"), ("Y", "YGGDRASIL", "Bring your server", "#9B86FF"), ("O", "OFFLINE", "Fast local profile", "#51E1A5")]
    for i, (letter, title, copy, color) in enumerate(accounts):
        angle_x = 235 + i * 405
        body += f'''<g><circle cx="{angle_x + 130}" cy="530" r="104" fill="#15182A" stroke="{color}" stroke-width="3"/><circle cx="{angle_x + 130}" cy="530" r="72" fill="{color}" fill-opacity=".13"/><text x="{angle_x + 130}" y="553" text-anchor="middle" class="hero" font-size="62" fill="{color}">{letter}</text>
        <text x="{angle_x + 130}" y="694" text-anchor="middle" class="card-title">{title}</text><text x="{angle_x + 130}" y="730" text-anchor="middle" class="card-copy">{copy}</text></g>'''
    body += pill(750, 820, "TOKENS SEALED LOCALLY", "#51E1A5", 420)
    result.append((s["id"], base(s, body, 6)))

    s = STORYBOARD[7]
    body = scene_heading(s["title"], s["copy"], 185)
    queues = [("Minecraft client", 100, "VERIFIED", "#51E1A5"), ("Shared libraries", 78, "DOWNLOADING", "#9B86FF"), ("Asset objects", 43, "PAUSED", "#FFBE66"), ("Java runtime 21", 100, "READY", "#5EE6FF")]
    body += '<g><rect x="120" y="300" width="1680" height="585" rx="38" class="glass"/>'
    for i, (name, value, status, color) in enumerate(queues):
        y = 366 + i * 122
        width = int(1110 * value / 100)
        body += f'''<text x="174" y="{y + 8}" class="card-title">{name}</text><text x="1680" y="{y + 8}" text-anchor="end" class="pill" fill="{color}">{status}</text>
        <rect x="174" y="{y + 34}" width="1506" height="18" rx="9" fill="#272B45"/><rect x="174" y="{y + 34}" width="{width * 1506 // 1110}" height="18" rx="9" fill="{color}"/><text x="174" y="{y + 82}" class="tiny">{value}% · checksum protected · resumable</text>'''
    body += '</g>'
    result.append((s["id"], base(s, body, 7)))

    s = STORYBOARD[8]
    body = scene_heading(s["title"], s["copy"], 178)
    body += '''<g><rect x="120" y="295" width="1680" height="590" rx="38" class="glass"/>
    <rect x="160" y="335" width="905" height="510" rx="28" fill="#0D1020"/><ellipse cx="610" cy="580" rx="360" ry="210" fill="url(#halo)"/>
    <path d="M210 660 C360 410 510 760 660 500 S930 435 1020 610" fill="none" stroke="url(#brand)" stroke-width="8" stroke-linecap="round"/><path d="M225 730 C420 570 575 790 750 610 S940 610 1010 520" fill="none" stroke="#5EE6FF" stroke-opacity=".55" stroke-width="3"/>
    <g transform="translate(1110 350)"><rect width="640" height="94" rx="22" fill="#171A2D" stroke="#9B86FF" stroke-opacity=".45"/><text x="32" y="38" class="card-title">◉ Glow Node</text><text x="32" y="69" class="card-copy">soft light · 72%</text>
    <rect y="122" width="640" height="94" rx="22" fill="#171A2D" stroke="#5EE6FF" stroke-opacity=".45"/><text x="32" y="160" class="card-title">◉ Flow Node</text><text x="32" y="191" class="card-copy">motion · 0.55</text>
    <rect y="244" width="640" height="94" rx="22" fill="#171A2D" stroke="#FF5FD2" stroke-opacity=".45"/><text x="32" y="282" class="card-title">◉ Accent Color</text><text x="32" y="313" class="card-copy">#9B86FF</text>
    <rect y="366" width="640" height="94" rx="22" fill="#171A2D" stroke="#51E1A5" stroke-opacity=".45"/><text x="32" y="404" class="card-title">◉ Glass Node</text><text x="32" y="435" class="card-copy">global surface · 76%</text></g></g>'''
    result.append((s["id"], base(s, body, 8)))

    s = STORYBOARD[9]
    body = scene_heading(s["title"], s["copy"], 185)
    paths = [("D:\\Selene\\Downloads", "DOWNLOADS", "#5EE6FF"), ("E:\\Games\\Instances", "INSTANCES", "#9B86FF"), ("E:\\Minecraft\\Shared", "SHARED FILES", "#FF5FD2"), ("F:\\Java\\Runtimes", "JAVA", "#51E1A5")]
    for i, (path, label, color) in enumerate(paths):
        x = 120 + (i % 2) * 850
        y = 320 + (i // 2) * 205
        extra = f'''<text x="{x + 42}" y="{y + 132}" class="card-title" font-size="25">{esc(path)}</text><rect x="{x + 610}" y="{y + 104}" width="154" height="48" rx="24" fill="{color}" fill-opacity=".15"/><text x="{x + 687}" y="{y + 135}" text-anchor="middle" class="pill" fill="{color}">BROWSE</text>'''
        body += card(x, y, 800, 170, label, "Writable path verified before save", color, extra)
    body += f'''<g><rect x="120" y="765" width="1630" height="112" rx="30" fill="#121A21" stroke="#51E1A5" stroke-opacity=".35"/><circle cx="178" cy="821" r="24" fill="#51E1A5" fill-opacity=".15"/><path d="M166 821 L176 831 L193 810" fill="none" stroke="#51E1A5" stroke-width="5" stroke-linecap="round"/><text x="222" y="810" class="card-title">Diagnostics ready</text><text x="222" y="842" class="card-copy">Rotating logs · privacy-safe export · game output captured</text>{pill(1460, 800, 'EXPORT ZIP', '#51E1A5', 230)}</g>'''
    result.append((s["id"], base(s, body, 9)))

    s = STORYBOARD[10]
    body = f'''<ellipse cx="960" cy="500" rx="640" ry="430" fill="url(#halo)" opacity=".8"/>{moon_logo(960, 420, 280)}
    <text x="960" y="650" text-anchor="middle" class="hero" font-size="100">SELENE LAUNCHER</text>
    <text x="960" y="720" text-anchor="middle" class="copy" font-size="34">Less setup. More world.</text>
    <g transform="translate(615 790)">{pill(0, 0, 'INSTALL', '#5EE6FF', 210)}{pill(240, 0, 'CREATE', '#9B86FF', 210)}{pill(480, 0, 'PLAY', '#FF5FD2', 210)}</g>
    <text x="960" y="915" text-anchor="middle" class="tiny">MINECRAFT JAVA EDITION · WINDOWS X64</text>'''
    result.append((s["id"], base(s, body, 10)))
    return result


def write_assets() -> list[Path]:
    VECTORS.mkdir(parents=True, exist_ok=True)
    RENDERED.mkdir(parents=True, exist_ok=True)
    paths = []
    for name, svg in scenes():
        path = VECTORS / f"{name}.svg"
        path.write_text(svg, encoding="utf-8")
        paths.append(path)
    (MEDIA / "storyboard.json").write_text(json.dumps(STORYBOARD, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    motion_design = {
        "style": MOTION_STYLE,
        "fps": FPS,
        "durationSeconds": round(len(STORYBOARD) * CLIP_DURATION - (len(STORYBOARD) - 1) * TRANSITION, 2),
        "motion": [
            "decaying-cosine spring camera with overshoot and recoil",
            "alternating parallax drift and micro push-in",
            "chromatic edge separation and two-frame impact flashes",
            "technical grid, optical vignette and HUD safe-frame",
            "124 BPM synthesized electronic pulse with scene impacts",
        ],
        "transitions": [
            "horizontal slice", "pixel displacement", "radial aperture", "horizontal squeeze",
            "diagonal wipe", "motion blur", "vertical slice", "circle aperture",
            "smooth slide", "distance field",
        ],
    }
    (MEDIA / "motion-design.json").write_text(
        json.dumps(motion_design, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    return paths


def rasterize(svg_paths: list[Path]) -> list[Path]:
    pngs = []
    for svg in svg_paths:
        png = RENDERED / (svg.stem + ".png")
        run(["ffmpeg", "-hide_banner", "-loglevel", "error", "-y", "-i", str(svg), "-frames:v", "1", str(png)])
        pngs.append(png)
    shutil.copy2(pngs[0], MEDIA / "cover.png")
    return pngs


def render_video(pngs: list[Path], output: Path = VIDEO, draft: bool = False) -> None:
    """Animate the SVG key art as one energetic motion-design composition."""
    DIST.mkdir(parents=True, exist_ok=True)
    selected = pngs[:3] if draft else pngs
    command = ["ffmpeg", "-hide_banner", "-loglevel", "warning", "-y"]
    for png in selected:
        command += ["-loop", "1", "-framerate", str(FPS), "-t", str(CLIP_DURATION), "-i", str(png)]

    scene_step = CLIP_DURATION - TRANSITION
    total = len(selected) * CLIP_DURATION - (len(selected) - 1) * TRANSITION
    # A copyright-safe electronic score: pulse, sub impact, glassy arpeggio and
    # scene-change hit. Envelopes are synthesized directly from the timeline.
    beat = 60 / 124
    score = (
        "aevalsrc="
        f"0.10*sin(2*PI*55*t)+0.035*sin(2*PI*110*t+0.8*sin(2*PI*0.12*t))"
        f"+0.20*sin(2*PI*(72-32*mod(t\,{beat:.6f}))*t)*exp(-15*mod(t\,{beat:.6f}))"
        f"+0.038*sin(2*PI*660*t)*exp(-28*mod(t\,{beat / 2:.6f}))"
        f"+0.11*sin(2*PI*(115-54*mod(t\,{scene_step:.6f}))*t)*exp(-7*mod(t\,{scene_step:.6f}))"
        f":s=48000:d={total:.3f}"
    )
    command += ["-f", "lavfi", "-i", score]

    filters: list[str] = []
    for i in range(len(selected)):
        direction = -1 if i % 2 else 1
        # Decaying cosine camera motion approximates an AE spring expression:
        # overshoot -> recoil -> settle, followed by slow premium parallax.
        zoom = "max(1.001,1.026+0.052*exp(-on/14)*cos(on*0.56)+0.000018*on)"
        x = (
            "iw/2-(iw/zoom/2)"
            f"+{direction}*(190*exp(-on/11)*cos(on*0.47)+8*sin(on/72))"
        )
        y = (
            "ih/2-(ih/zoom/2)"
            f"+{-direction}*(76*exp(-on/13)*cos(on*0.53)+5*cos(on/83))"
        )
        filters.append(
            f"[{i}:v]zoompan=z='{zoom}':x='{x}':y='{y}':d=1:s={W}x{H}:fps={FPS},"
            "eq=contrast=1.055:saturation=1.16:brightness='0.055*exp(-t/0.22)':eval=frame,"
            "rgbashift=rh=2:bh=-2:edge=smear,"
            "drawgrid=width=96:height=96:thickness=1:color=0x8f86ff@0.045,"
            "drawbox=x=34:y=34:w=1852:h=1012:color=0x8feaff@0.13:t=1,"
            "drawbox=x=60:y=1004:w=1800:h=2:color=0xff5fd2@0.16:t=fill,"
            f"drawtext=font='{FONT}':text='0{i + 1:02d}  //  M O T I O N   S Y S T E M':"
            "x=74:y=970:fontsize=13:fontcolor=white@0.34,"
            "vignette=PI/5.3:eval=frame,unsharp=5:5:0.38:5:5:0.0,"
            f"format=yuv420p,setpts=PTS-STARTPTS[v{i}]"
        )

    current = "v0"
    transitions = [
        "hlslice", "pixelize", "radial", "squeezeh", "diagbr",
        "hblur", "vuslice", "circleopen", "smoothleft", "distance",
    ]
    for i in range(1, len(selected)):
        offset = i * scene_step
        label = f"x{i}"
        transition = transitions[(i - 1) % len(transitions)]
        filters.append(
            f"[{current}][v{i}]xfade=transition={transition}:"
            f"duration={TRANSITION}:offset={offset:.3f}[{label}]"
        )
        current = label

    # Impact flashes make each edit land like an AE adjustment-layer hit.
    for i in range(1, len(selected)):
        hit = i * scene_step
        label = f"hit{i}"
        color = "0x9beaff" if i % 2 else "0xff8de1"
        filters.append(
            f"[{current}]drawbox=x=0:y=0:w=iw:h=ih:color={color}@0.22:t=fill:"
            f"enable='between(t,{hit:.3f},{hit + 0.067:.3f})'[{label}]"
        )
        current = label

    audio_index = len(selected)
    filters.append(
        f"[{audio_index}:a]aecho=0.8:0.72:58|116:0.13|0.06,"
        f"lowpass=f=5200,highpass=f=36,acompressor=threshold=-13dB:ratio=3.2:attack=7:release=140,"
        f"afade=t=in:st=0:d=1.2,afade=t=out:st={total - 3.2:.3f}:d=3.2,volume=.82[a]"
    )
    preset, crf = ("ultrafast", "24") if draft else ("medium", "17")
    command += [
        "-filter_complex", ";".join(filters), "-map", f"[{current}]", "-map", "[a]",
        "-t", f"{total:.3f}", "-c:v", "libx264", "-preset", preset, "-crf", crf,
        "-profile:v", "high", "-level", "4.2", "-pix_fmt", "yuv420p", "-movflags", "+faststart",
        "-c:a", "aac", "-b:a", "256k", str(output),
    ]
    run(command)


def write_readme() -> Path:
    readme = MEDIA / "README.txt"
    readme.write_text(
        "Selene Launcher AE-style kinetic vector promotion film\n"
        "=======================================================\n\n"
        "Duration: approximately 72.5 seconds\n"
        "Master: 1920x1080, 30 fps, H.264 High + AAC 256 kbps\n"
        "Style: high-energy AE-inspired technology motion design\n\n"
        "Motion language\n"
        "---------------\n"
        "Spring overshoot and recoil, camera parallax, chromatic impact frames,\n"
        "HUD sweeps, optical vignette, and ten distinct technology transitions.\n"
        "The original 124 BPM electronic score is synthesized during rendering.\n\n"
        "Re-render\n"
        "---------\n"
        "Requires Python 3 and FFmpeg with SVG and libx264 support.\n"
        "From the project root run:\n"
        "  python3 media/promo/render_promo.py\n\n"
        "The vectors/ directory contains editable SVG key art. storyboard.json\n"
        "contains timing and copy; motion-design.json documents animation choices.\n"
        "No third-party video, artwork, music, or copyrighted template is used.\n",
        encoding="utf-8",
    )
    return readme


def package(svg_paths: list[Path], readme: Path) -> None:
    with zipfile.ZipFile(BUNDLE, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        archive.write(VIDEO, VIDEO.name)
        archive.write(readme, "README.txt")
        archive.write(MEDIA / "storyboard.json", "storyboard.json")
        archive.write(MEDIA / "motion-design.json", "motion-design.json")
        archive.write(MEDIA / "cover.png", "cover.png")
        archive.write(Path(__file__), "source/render_promo.py")
        for svg in svg_paths:
            archive.write(svg, f"source/vectors/{svg.name}")


def probe() -> None:
    run(["ffprobe", "-v", "error", "-show_entries", "format=duration,size:stream=codec_name,width,height,r_frame_rate",
         "-of", "default=noprint_wrappers=1", str(VIDEO)])


def main() -> int:
    if shutil.which("ffmpeg") is None or shutil.which("ffprobe") is None:
        print("FFmpeg and ffprobe are required", file=sys.stderr)
        return 2
    svg_paths = write_assets()
    readme = write_readme()
    pngs = rasterize(svg_paths)
    render_video(pngs)
    probe()
    package(svg_paths, readme)
    print(f"Video: {VIDEO}")
    print(f"Bundle: {BUNDLE}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
