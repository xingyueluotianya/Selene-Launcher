Selene Launcher AE-style kinetic vector promotion film
=======================================================

Duration: approximately 72.5 seconds
Master: 1920x1080, 30 fps, H.264 High + AAC 256 kbps
Style: high-energy AE-inspired technology motion design

Motion language
---------------
Spring overshoot and recoil, camera parallax, chromatic impact frames,
HUD sweeps, optical vignette, and ten distinct technology transitions.
The original 124 BPM electronic score is synthesized during rendering.

Re-render
---------
Requires Python 3 and FFmpeg with SVG and libx264 support.
From the project root run:
  python3 media/promo/render_promo.py

The vectors/ directory contains editable SVG key art. storyboard.json
contains timing and copy; motion-design.json documents animation choices.
No third-party video, artwork, music, or copyrighted template is used.
