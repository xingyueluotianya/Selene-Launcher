package io.selene.launcher;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;

class StartupFailureReporterTest {
    @Test
    void writesAReadableEmergencyLog(@TempDir Path directory) throws Exception {
        Path log = StartupFailureReporter.writeEmergencyLog(
                new IllegalStateException("logical startup failure"), "unit-test", java.util.List.of(directory));

        assertThat(log).isNotNull().isRegularFile();
        assertThat(Files.readString(log))
                .contains("启动阶段：unit-test")
                .contains("logical startup failure")
                .contains("IllegalStateException");
    }

    @Test
    void fallsBackWhenThePreferredLogDirectoryIsUnavailable(@TempDir Path directory) throws Exception {
        Path unavailable = Files.writeString(directory.resolve("not-a-directory"), "occupied");
        Path fallback = directory.resolve("fallback");

        Path log = StartupFailureReporter.writeEmergencyLog(
                new IllegalStateException("fallback failure"), "unit-test",
                java.util.List.of(unavailable, fallback));

        assertThat(log).isEqualTo(fallback.resolve("startup-failure.log").toAbsolutePath().normalize());
        assertThat(Files.readString(log)).contains("fallback failure");
    }
}
