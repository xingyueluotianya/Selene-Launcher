package io.selene.launcher.infra;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;

class HashingTest {
    @Test
    void computesSha256(@TempDir Path temporaryDirectory) throws Exception {
        Path file = temporaryDirectory.resolve("payload.txt");
        Files.writeString(file, "Selene Launcher");

        assertThat(Hashing.sha256(file))
                .isEqualTo("37a6006eaa892988f358afa844f9c1418289c3206b107cd190ac5fa42273ceeb");
    }

    @Test
    void computesMojangCompatibleSha1(@TempDir Path temporaryDirectory) throws Exception {
        Path file = temporaryDirectory.resolve("abc.txt");
        Files.writeString(file, "abc");

        assertThat(Hashing.sha1(file))
                .isEqualTo("a9993e364706816aba3e25717850c26c9cd0d89d");
    }
}
