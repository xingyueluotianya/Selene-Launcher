package io.selene.launcher.application;

import io.selene.launcher.core.model.GameInstance;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.assertj.core.api.Assertions.assertThat;

class ModRepairServiceTest {
    @Test
    void diagnosesMissingFabricDependencyAndWrongInstalledVersion(@TempDir Path root) throws Exception {
        GameInstance instance = instance(root.resolve("fabric-instance"));
        Path mods = instance.directory().resolve("game/mods");
        Files.createDirectories(mods);
        Path helper = mods.resolve("helper-1.0.jar");
        fabricMod(helper, "helper", "Helper Library", "1.0.0");
        Files.createDirectories(instance.directory().resolve("logs"));
        Files.writeString(instance.directory().resolve("logs/latest.log"), """
                Incompatible mod set!
                - Install cloth-config, version 11.1.0 or later.
                Mod 'Example' (example) requires version 2.0.0 or later of mod 'helper', but only the wrong version is present: 1.0.0!
                """);
        ModRepairService service = service(root, instance);

        var issues = service.diagnose(instance);

        assertThat(issues).hasSize(2);
        assertThat(issues).anySatisfy(issue -> {
            assertThat(issue.type()).isEqualTo(ModRepairService.IssueType.MISSING_DEPENDENCY);
            assertThat(issue.modId()).isEqualTo("cloth-config");
            assertThat(issue.requiredVersion()).contains("11.1.0");
        });
        assertThat(issues).anySatisfy(issue -> {
            assertThat(issue.type()).isEqualTo(ModRepairService.IssueType.WRONG_VERSION);
            assertThat(issue.modId()).isEqualTo("helper");
            assertThat(issue.installedVersion()).isEqualTo("1.0.0");
            assertThat(issue.sourceFile()).isEqualTo(helper);
        });
    }

    @Test
    void diagnosesForgeMissingDependency(@TempDir Path root) throws Exception {
        GameInstance instance = instance(root.resolve("forge-instance"));
        Files.createDirectories(instance.directory().resolve("logs"));
        Files.writeString(instance.directory().resolve("logs/latest.log"), """
                Missing or unsupported mandatory dependencies:
                Mod ID: curios
                Expected range: [5.4.0,)
                Actual version: [MISSING]
                """);
        ModRepairService service = service(root, instance);

        assertThat(service.diagnose(instance)).singleElement().satisfies(issue -> {
            assertThat(issue.type()).isEqualTo(ModRepairService.IssueType.MISSING_DEPENDENCY);
            assertThat(issue.modId()).isEqualTo("curios");
            assertThat(issue.requiredVersion()).isEqualTo("[5.4.0,)");
        });
    }

    private ModRepairService service(Path root, GameInstance instance) {
        VanillaGameService games = new VanillaGameService(null, root.resolve("instances"), root.resolve("shared"));
        return new ModRepairService(games, null);
    }

    private GameInstance instance(Path directory) throws Exception {
        Files.createDirectories(directory.resolve("game/mods"));
        Files.createDirectories(directory);
        Files.writeString(directory.resolve("instance.json"), """
                {"baseGameVersion":"1.20.1","loader":"fabric"}
                """);
        return new GameInstance(directory.getFileName().toString(), "测试实例", "fabric-test", directory,
                "net.minecraft.client.main.Main", 17, Instant.parse("2026-03-28T00:00:00Z"));
    }

    private void fabricMod(Path path, String id, String name, String version) throws Exception {
        try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(path))) {
            zip.putNextEntry(new ZipEntry("fabric.mod.json"));
            zip.write(("""
                    {"id":"%s","name":"%s","version":"%s"}
                    """).formatted(id, name, version).getBytes(StandardCharsets.UTF_8));
            zip.closeEntry();
        }
    }
}
