package io.selene.launcher.application;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;

class FailureDiagnosticServiceTest {
    private final FailureDiagnosticService diagnostics = new FailureDiagnosticService();

    @Test
    void recognizesChecksumAndNetworkInstallationFailures() {
        var checksum = diagnostics.diagnoseInstallation("Fabric 1.21.1",
                new IOException("SHA-1 checksum mismatch for loader.jar"));
        var network = diagnostics.diagnoseInstallation("NeoForge 1.21.1",
                new IOException("official source returned HTTP 503"));

        assertThat(checksum.title()).isEqualTo("下载文件校验失败");
        assertThat(checksum.retryable()).isTrue();
        assertThat(network.title()).isEqualTo("网络源暂时不可用");
        assertThat(network.displayText()).contains("HTTP 503", "稍后重试");
    }

    @Test
    void recognizesModFailureFromLaunchLog(@TempDir Path root) throws Exception {
        Path log = Files.writeString(root.resolve("latest.log"), """
                Incompatible mod set!
                Mod 'Example' (example) requires version 2.0 or later of helper, which is missing!
                """);

        var diagnosis = diagnostics.diagnoseLaunch(log, 1);

        assertThat(diagnosis.title()).isEqualTo("检测到模组依赖或版本冲突");
        assertThat(diagnosis.displayText()).contains("模组管理", "扫描模组问题清单");
    }
}
