package io.selene.launcher.application;

import io.selene.launcher.infra.AppPaths;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashSet;
import java.util.Set;
import java.util.zip.ZipFile;

import static org.assertj.core.api.Assertions.assertThat;

class DiagnosticServiceTest {
    @Test
    void exportsLogsButNeverAccountSecrets(@TempDir Path directory) throws Exception {
        AppPaths paths = new AppPaths(directory);
        Files.createDirectories(paths.logsDirectory());
        Files.createDirectories(paths.configDirectory());
        Files.writeString(paths.logsDirectory().resolve("launcher-0.log"), "diagnostic line");
        Files.writeString(paths.configDirectory().resolve("settings.json"), "{}");
        Files.writeString(paths.configDirectory().resolve("accounts.json"), "secret-token");
        Files.writeString(paths.configDirectory().resolve("credential.key"), "secret-key");

        Path archive = new DiagnosticService(paths).export();

        assertThat(archive).exists();
        try (ZipFile zip = new ZipFile(archive.toFile())) {
            Set<String> entries = new HashSet<>();
            zip.stream().forEach(entry -> entries.add(entry.getName()));
            assertThat(entries).contains("system-info.txt", "launcher-logs/launcher-0.log", "config/settings.json");
            assertThat(entries).doesNotContain("config/accounts.json", "config/credential.key");
        }
    }
}
