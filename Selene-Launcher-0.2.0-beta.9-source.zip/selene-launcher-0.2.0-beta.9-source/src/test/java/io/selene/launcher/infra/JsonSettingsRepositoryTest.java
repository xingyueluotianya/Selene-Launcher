package io.selene.launcher.infra;

import io.selene.launcher.core.model.LauncherSettings;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;

class JsonSettingsRepositoryTest {
    @Test
    void returnsDefaultsWhenConfigurationDoesNotExist(@TempDir Path directory) throws Exception {
        JsonSettingsRepository repository = new JsonSettingsRepository(directory.resolve("settings.json"));

        assertThat(repository.load()).isEqualTo(LauncherSettings.defaults());
    }

    @Test
    void loadsLegacySettingsWithoutCustomPaths(@TempDir Path directory) throws Exception {
        Path file = directory.resolve("settings.json");
        Files.writeString(file, """
                {
                  "locale": "zh-CN",
                  "theme": "midnight",
                  "maxConcurrentDownloads": 4,
                  "playIntro": true,
                  "preferMirror": false,
                  "activeProfileId": "default",
                  "onboardingCompleted": true
                }
                """);

        LauncherSettings loaded = new JsonSettingsRepository(file).load();

        assertThat(loaded.downloadsDirectory()).isEmpty();
        assertThat(loaded.instancesDirectory()).isEmpty();
        assertThat(loaded.sharedMinecraftDirectory()).isEmpty();
        assertThat(loaded.runtimesDirectory()).isEmpty();
    }

    @Test
    void defaultsToEnglishWhenLocaleIsMissing(@TempDir Path directory) throws Exception {
        Path file = directory.resolve("settings.json");
        Files.writeString(file, """
                {
                  "theme": "midnight",
                  "maxConcurrentDownloads": 4,
                  "playIntro": true,
                  "preferMirror": false,
                  "activeProfileId": "default",
                  "onboardingCompleted": true
                }
                """);

        assertThat(new JsonSettingsRepository(file).load().locale()).isEqualTo("en-US");
    }

    @Test
    void persistsAndLoadsSettings(@TempDir Path directory) throws Exception {
        JsonSettingsRepository repository = new JsonSettingsRepository(directory.resolve("settings.json"));
        LauncherSettings expected = new LauncherSettings(
                "zh-CN", "midnight", 8, false, true, "player-one", true,
                directory.resolve("downloads").toString(), directory.resolve("instances").toString(),
                directory.resolve("minecraft").toString(), directory.resolve("runtimes").toString()
        );

        repository.save(expected);

        assertThat(repository.load()).isEqualTo(expected);
    }
}
