package io.selene.launcher.application;

import io.selene.launcher.core.model.GameInstance;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.util.concurrent.CompletionException;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class ModpackImportServiceTest {
    @Test
    void importsGenericZipIntoGameDirectory(@TempDir Path directory) throws Exception {
        Path archive = directory.resolve("本地整合包.zip");
        try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(archive))) {
            zip.putNextEntry(new ZipEntry(".minecraft/mods/example.jar"));
            zip.write("mod".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zip.closeEntry();
            zip.putNextEntry(new ZipEntry("minecraft/config/example.toml"));
            zip.write("enabled=true".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zip.closeEntry();
        }
        GameInstance instance = instance(directory.resolve("instance"));
        ModpackImportService importer = new ModpackImportService(null);

        int count = importer.importArchive(archive, instance, ignored -> { }).join();

        assertThat(count).isEqualTo(2);
        assertThat(instance.directory().resolve("game/mods/example.jar")).hasContent("mod");
        assertThat(instance.directory().resolve("game/config/example.toml")).hasContent("enabled=true");
    }

    @Test
    void rejectsZipSlipPaths(@TempDir Path directory) throws Exception {
        Path archive = directory.resolve("unsafe.zip");
        try (ZipOutputStream zip = new ZipOutputStream(Files.newOutputStream(archive))) {
            zip.putNextEntry(new ZipEntry("../outside.txt"));
            zip.write("unsafe".getBytes(java.nio.charset.StandardCharsets.UTF_8));
            zip.closeEntry();
        }
        ModpackImportService importer = new ModpackImportService(null);

        assertThatThrownBy(() -> importer.importArchive(archive, instance(directory.resolve("instance")), ignored -> { }).join())
                .isInstanceOf(CompletionException.class)
                .hasRootCauseMessage("整合包包含不安全路径：../outside.txt");
        assertThat(directory.resolve("outside.txt")).doesNotExist();
    }

    @Test
    void onlyAcceptsSupportedArchiveExtensions(@TempDir Path directory) throws Exception {
        Path zip = Files.writeString(directory.resolve("pack.zip"), "x");
        Path mrpack = Files.writeString(directory.resolve("pack.mrpack"), "x");
        Path jar = Files.writeString(directory.resolve("mod.jar"), "x");
        ModpackImportService importer = new ModpackImportService(null);

        assertThat(importer.accepts(zip)).isTrue();
        assertThat(importer.accepts(mrpack)).isTrue();
        assertThat(importer.accepts(jar)).isFalse();
    }

    private GameInstance instance(Path directory) {
        return new GameInstance("test", "测试实例", "1.21.1", directory,
                "net.minecraft.client.main.Main", 21, Instant.parse("2026-03-28T00:00:00Z"));
    }
}
