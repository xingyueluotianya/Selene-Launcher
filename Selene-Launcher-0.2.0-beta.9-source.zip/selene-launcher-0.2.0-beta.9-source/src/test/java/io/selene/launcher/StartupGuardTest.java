package io.selene.launcher;

import org.junit.jupiter.api.Test;

import java.net.URL;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;

class StartupGuardTest {
    @Test
    void acceptsTheCurrentPackagedRuntimeClasspath() {
        List<String> problems = StartupGuard.inspect(getClass().getClassLoader(), 21);

        assertThat(problems).isEmpty();
    }

    @Test
    void reportsOldJavaMissingDependenciesAndMissingResources() {
        ClassLoader empty = new ClassLoader(null) {
            @Override
            public URL getResource(String name) {
                return null;
            }
        };

        List<String> problems = StartupGuard.inspect(empty, 17);

        assertThat(problems).anyMatch(value -> value.contains("需要 Java 21"));
        assertThat(problems).anyMatch(value -> value.contains("javafx.application.Application"));
        assertThat(problems).anyMatch(value -> value.contains("selene.css"));
    }
}
