package io.selene.launcher.ui;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class FirstRunWizardTest {
    @Test
    void doesNotBindDialogToPrimaryStageBeforeItsSceneExists() {
        assertThat(FirstRunWizard.shouldInitializeOwner(true, false)).isFalse();
    }

    @Test
    void bindsDialogOnlyWhenOwnerAndSceneAreBothAvailable() {
        assertThat(FirstRunWizard.shouldInitializeOwner(false, false)).isFalse();
        assertThat(FirstRunWizard.shouldInitializeOwner(false, true)).isFalse();
        assertThat(FirstRunWizard.shouldInitializeOwner(true, true)).isTrue();
    }
}
