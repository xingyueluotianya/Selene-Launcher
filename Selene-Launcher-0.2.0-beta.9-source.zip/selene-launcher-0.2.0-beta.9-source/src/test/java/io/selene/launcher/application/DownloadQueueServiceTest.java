package io.selene.launcher.application;

import io.selene.launcher.core.model.DownloadTask;
import io.selene.launcher.core.port.DownloadService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Consumer;

import static org.assertj.core.api.Assertions.assertThat;

class DownloadQueueServiceTest {
    @Test
    void pausesPersistsAndResumes(@TempDir Path directory) throws Exception {
        ControlledDownloadService downloads = new ControlledDownloadService();
        Path queueFile = directory.resolve("queue.json");
        DownloadQueueService queue = new DownloadQueueService(downloads, queueFile);
        Path destination = directory.resolve("artifact.bin");

        String id = queue.enqueue("测试文件", request(destination));
        queue.pause(id);
        downloads.tick();

        assertThat(queue.tasks().getFirst().status()).isEqualTo(DownloadTask.Status.PAUSED);
        assertThat(queueFile).exists();

        queue.resume(id);
        downloads.complete(destination);

        assertThat(queue.completion(id).join()).isEqualTo(destination);
        assertThat(queue.tasks().getFirst().status()).isEqualTo(DownloadTask.Status.COMPLETED);
        assertThat(Files.readString(queueFile)).contains("COMPLETED");
    }

    @Test
    void reusesTaskForSameDestination(@TempDir Path directory) {
        ControlledDownloadService downloads = new ControlledDownloadService();
        DownloadQueueService queue = new DownloadQueueService(downloads, directory.resolve("queue.json"));
        Path destination = directory.resolve("same.bin");

        String first = queue.enqueue("第一次", request(destination));
        String second = queue.enqueue("第二次", request(destination));

        assertThat(second).isEqualTo(first);
        assertThat(queue.tasks()).hasSize(1);
    }

    @Test
    void refreshesSavedCandidatesWhenSameDestinationIsEnqueuedAgain(@TempDir Path directory) {
        ControlledDownloadService downloads = new ControlledDownloadService();
        DownloadQueueService queue = new DownloadQueueService(downloads, directory.resolve("queue.json"));
        Path destination = directory.resolve("loader.jar");
        String id = queue.enqueue("旧来源", request(destination));
        queue.pause(id);
        downloads.tick();

        DownloadService.DownloadRequest refreshed = new DownloadService.DownloadRequest(
                List.of(URI.create("https://mirror.example/new"), URI.create("https://example.invalid/file")),
                destination, "", -1
        );
        String reused = queue.enqueue("新来源", refreshed);

        assertThat(reused).isEqualTo(id);
        assertThat(queue.tasks().getFirst().request()).isEqualTo(refreshed);
        assertThat(downloads.request.get()).isEqualTo(refreshed);
    }

    @Test
    void restoresActiveTaskAsQueued(@TempDir Path directory) throws Exception {
        Path destination = directory.resolve("recovered.bin");
        Path queueFile = directory.resolve("queue.json");
        String json = """
                {
                  "schemaVersion" : 1,
                  "tasks" : [ {
                    "id" : "recovered",
                    "name" : "恢复任务",
                    "candidates" : [ "https://example.invalid/file" ],
                    "destination" : "%s",
                    "checksum" : "",
                    "checksumAlgorithm" : "NONE",
                    "expectedSize" : -1,
                    "status" : "DOWNLOADING",
                    "downloadedBytes" : 12,
                    "totalBytes" : 100,
                    "detail" : "下载中",
                    "createdAt" : "2026-03-27T12:00:00Z",
                    "updatedAt" : "2026-03-27T12:00:01Z"
                  } ]
                }
                """.formatted(destination.toString().replace("\\", "\\\\"));
        Files.writeString(queueFile, json);
        ControlledDownloadService downloads = new ControlledDownloadService();

        DownloadQueueService queue = new DownloadQueueService(downloads, queueFile);

        assertThat(queue.tasks().getFirst().status()).isEqualTo(DownloadTask.Status.QUEUED);
        assertThat(downloads.request.get()).isNotNull();
    }

    private DownloadService.DownloadRequest request(Path destination) {
        return new DownloadService.DownloadRequest(
                List.of(URI.create("https://example.invalid/file")), destination, "", -1
        );
    }

    private static final class ControlledDownloadService implements DownloadService {
        private final AtomicReference<DownloadRequest> request = new AtomicReference<>();
        private Consumer<DownloadProgress> listener;
        private DownloadControl control;
        private CompletableFuture<Path> future;

        @Override
        public CompletableFuture<Path> download(DownloadRequest request, Consumer<DownloadProgress> progressListener) {
            return download(request, progressListener, DownloadControl.NONE);
        }

        @Override
        public CompletableFuture<Path> download(
                DownloadRequest request,
                Consumer<DownloadProgress> progressListener,
                DownloadControl control
        ) {
            this.request.set(request);
            this.listener = progressListener;
            this.control = control;
            this.future = new CompletableFuture<>();
            progressListener.accept(new DownloadProgress(0, request.expectedSize(), DownloadProgress.Status.QUEUED));
            return future;
        }

        void tick() {
            if (control.pauseRequested()) {
                listener.accept(new DownloadProgress(0, -1, DownloadProgress.Status.PAUSED));
                future.completeExceptionally(new IllegalStateException("paused"));
            }
        }

        void complete(Path destination) throws Exception {
            Files.writeString(destination, "done");
            listener.accept(new DownloadProgress(4, 4, DownloadProgress.Status.COMPLETED));
            future.complete(destination);
        }
    }
}
