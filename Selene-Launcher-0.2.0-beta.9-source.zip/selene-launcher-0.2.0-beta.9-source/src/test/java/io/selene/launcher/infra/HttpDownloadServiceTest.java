package io.selene.launcher.infra;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import io.selene.launcher.core.port.DownloadService;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicReference;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class HttpDownloadServiceTest {
    private HttpServer server;

    @AfterEach
    void stopServer() {
        if (server != null) {
            server.stop(0);
        }
    }

    @Test
    void downloadsVerifiesAndAtomicallyCompletes(@TempDir Path directory) throws Exception {
        byte[] payload = "Selene resumable download".getBytes(StandardCharsets.UTF_8);
        server = serverWith("/artifact", exchange -> respond(exchange, 200, payload));
        Path destination = directory.resolve("artifact.bin");
        String sha256 = hashOf(directory, payload);
        List<DownloadService.DownloadProgress.Status> statuses = new ArrayList<>();

        Path result = service().download(
                request(uri("/artifact"), destination, sha256, payload.length),
                progress -> statuses.add(progress.status())
        ).join();

        assertThat(result).isEqualTo(destination.toAbsolutePath());
        assertThat(Files.readAllBytes(destination)).isEqualTo(payload);
        assertThat(Files.exists(directory.resolve("artifact.bin.part"))).isFalse();
        assertThat(statuses).containsSubsequence(
                DownloadService.DownloadProgress.Status.QUEUED,
                DownloadService.DownloadProgress.Status.CONNECTING,
                DownloadService.DownloadProgress.Status.DOWNLOADING,
                DownloadService.DownloadProgress.Status.VERIFYING,
                DownloadService.DownloadProgress.Status.COMPLETED
        );
    }

    @Test
    void resumesAnExistingPartFileWithRange(@TempDir Path directory) throws Exception {
        byte[] payload = "0123456789abcdef".getBytes(StandardCharsets.UTF_8);
        AtomicReference<String> receivedRange = new AtomicReference<>();
        server = serverWith("/resume", exchange -> {
            receivedRange.set(exchange.getRequestHeaders().getFirst("Range"));
            byte[] remainder = java.util.Arrays.copyOfRange(payload, 6, payload.length);
            exchange.getResponseHeaders().set("Content-Range", "bytes 6-15/16");
            respond(exchange, 206, remainder);
        });
        Path destination = directory.resolve("resume.bin");
        Files.write(destination.resolveSibling("resume.bin.part"), java.util.Arrays.copyOf(payload, 6));

        service().download(
                request(uri("/resume"), destination, hashOf(directory, payload), payload.length),
                ignored -> { }
        ).join();

        assertThat(receivedRange.get()).isEqualTo("bytes=6-");
        assertThat(Files.readAllBytes(destination)).isEqualTo(payload);
    }

    @Test
    void fallsBackToTheNextCandidate(@TempDir Path directory) throws Exception {
        byte[] payload = "mirror fallback".getBytes(StandardCharsets.UTF_8);
        server = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        server.createContext("/unavailable", exchange -> respond(exchange, 503, new byte[0]));
        server.createContext("/working", exchange -> respond(exchange, 200, payload));
        server.start();
        Path destination = directory.resolve("fallback.bin");
        DownloadService.DownloadRequest request = new DownloadService.DownloadRequest(
                List.of(uri("/unavailable"), uri("/working")),
                destination,
                hashOf(directory, payload),
                payload.length
        );

        service().download(request, ignored -> { }).join();

        assertThat(Files.readAllBytes(destination)).isEqualTo(payload);
    }

    @Test
    void rejectsInvalidContentAndDoesNotPublishDestination(@TempDir Path directory) throws Exception {
        byte[] payload = "tampered".getBytes(StandardCharsets.UTF_8);
        server = serverWith("/bad", exchange -> respond(exchange, 200, payload));
        Path destination = directory.resolve("bad.bin");
        List<DownloadService.DownloadProgress.Status> statuses = new ArrayList<>();

        assertThatThrownBy(() -> service().download(
                request(uri("/bad"), destination, "0".repeat(64), payload.length),
                progress -> statuses.add(progress.status())
        ).join())
                .isInstanceOf(CompletionException.class)
                .hasCauseInstanceOf(HttpDownloadService.DownloadFailedException.class);

        assertThat(destination).doesNotExist();
        assertThat(destination.resolveSibling("bad.bin.part")).doesNotExist();
        assertThat(statuses).endsWith(DownloadService.DownloadProgress.Status.FAILED);
    }

    @Test
    void productionServiceRejectsPlainHttp(@TempDir Path directory) {
        try (HttpDownloadService service = new HttpDownloadService(2)) {
            DownloadService.DownloadRequest request = request(
                    URI.create("http://example.invalid/file"),
                    directory.resolve("file.bin"),
                    "",
                    -1
            );

            assertThatThrownBy(() -> service.download(request, ignored -> { }))
                    .isInstanceOf(IllegalArgumentException.class)
                    .hasMessageContaining("Unsupported download URI");
        }
    }

    private HttpDownloadService service() {
        return new HttpDownloadService(HttpClient.newHttpClient(), Runnable::run, Set.of("http"));
    }

    private DownloadService.DownloadRequest request(
            URI uri,
            Path destination,
            String sha256,
            long expectedSize
    ) {
        return new DownloadService.DownloadRequest(List.of(uri), destination, sha256, expectedSize);
    }

    private HttpServer serverWith(String path, ExchangeHandler handler) throws IOException {
        HttpServer result = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        result.createContext(path, exchange -> {
            try {
                handler.handle(exchange);
            } finally {
                exchange.close();
            }
        });
        result.start();
        return result;
    }

    private URI uri(String path) {
        return URI.create("http://127.0.0.1:" + server.getAddress().getPort() + path);
    }

    private String hashOf(Path directory, byte[] payload) throws IOException {
        Path hashInput = directory.resolve("hash-input-" + Math.abs(java.util.Arrays.hashCode(payload)));
        Files.write(hashInput, payload);
        return Hashing.sha256(hashInput);
    }

    private static void respond(HttpExchange exchange, int status, byte[] payload) throws IOException {
        exchange.sendResponseHeaders(status, payload.length);
        exchange.getResponseBody().write(payload);
    }

    @FunctionalInterface
    private interface ExchangeHandler {
        void handle(HttpExchange exchange) throws IOException;
    }
}
