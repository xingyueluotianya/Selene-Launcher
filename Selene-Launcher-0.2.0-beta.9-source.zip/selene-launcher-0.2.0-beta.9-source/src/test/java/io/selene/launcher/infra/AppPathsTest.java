package io.selene.launcher.infra;

import io.selene.launcher.core.model.LauncherSettings;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;

class AppPathsTest {
    @Test
    void resolvesAndPreparesCustomLargeDataDirectories(@TempDir Path directory) throws Exception {
        Path root = directory.resolve("profile");
        LauncherSettings settings = new LauncherSettings(
                "zh-CN", "midnight", 4, true, false, "default", true,
                directory.resolve("drive-d/downloads").toString(),
                directory.resolve("drive-e/versions").toString(),
                directory.resolve("drive-e/minecraft-shared").toString(),
                directory.resolve("drive-f/java").toString()
        );

        AppPaths paths = AppPaths.fromSettings(root, settings);
        paths.prepareStorage();

        assertThat(paths.configDirectory()).isEqualTo(root.toAbsolutePath().resolve("config"));
        assertThat(paths.downloadsDirectory()).isDirectory();
        assertThat(paths.instancesDirectory()).isDirectory();
        assertThat(paths.sharedMinecraftDirectory()).isDirectory();
        assertThat(paths.runtimesDirectory()).isDirectory();
        assertThat(paths.toolsDirectory()).isEqualTo(paths.downloadsDirectory().resolve("launcher-tools"));
    }

    @Test
    void blankSettingsRetainCompatibleDefaults(@TempDir Path directory) {
        AppPaths paths = AppPaths.fromSettings(directory, LauncherSettings.defaults());

        assertThat(paths.downloadsDirectory()).isEqualTo(directory.resolve("downloads").toAbsolutePath());
        assertThat(paths.instancesDirectory()).isEqualTo(directory.resolve("instances").toAbsolutePath());
        assertThat(paths.sharedMinecraftDirectory()).isEqualTo(directory.resolve("minecraft").toAbsolutePath());
        assertThat(paths.runtimesDirectory()).isEqualTo(directory.resolve("runtimes").toAbsolutePath());
        assertThat(Files.notExists(paths.downloadsDirectory())).isTrue();
    }

    @Test
    void malformedSavedPathFallsBackInsteadOfCrashingStartup(@TempDir Path directory) {
        LauncherSettings settings = new LauncherSettings(
                "zh-CN", "midnight", 4, true, false, "default", true,
                "invalid\0downloads", "", "", ""
        );

        AppPaths paths = AppPaths.fromSettings(directory, settings);

        assertThat(paths.downloadsDirectory()).isEqualTo(directory.resolve("downloads").toAbsolutePath());
    }
}
