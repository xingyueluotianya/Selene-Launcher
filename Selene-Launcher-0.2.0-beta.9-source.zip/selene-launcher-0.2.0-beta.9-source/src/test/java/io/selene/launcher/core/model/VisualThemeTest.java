package io.selene.launcher.core.model;

import org.junit.jupiter.api.Test;

import static org.assertj.core.api.Assertions.assertThat;

class VisualThemeTest {
    @Test
    void clampsUnsafeValuesAndGeneratesPortableShaderSource() {
        VisualTheme theme = new VisualTheme("custom", 5, -2, 0.75, 0.5, "#32e6d1");

        assertThat(theme.glow()).isEqualTo(1);
        assertThat(theme.flow()).isZero();
        assertThat(theme.accent()).isEqualTo("#32E6D1");
        assertThat(theme.shaderSource())
                .contains("Selene Universal Shader Graph 1.0")
                .contains("uniform float u_glow   = 1.000")
                .contains("vec3(0.1961, 0.9020, 0.8196)");
    }
}
