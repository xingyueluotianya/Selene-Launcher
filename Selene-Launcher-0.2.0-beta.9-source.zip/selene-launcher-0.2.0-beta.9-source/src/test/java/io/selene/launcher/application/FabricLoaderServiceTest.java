package io.selene.launcher.application;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.selene.launcher.core.port.DownloadService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.net.URI;
import java.nio.file.Path;
import java.util.List;
import java.util.concurrent.CompletableFuture;

import static org.assertj.core.api.Assertions.assertThat;

class FabricLoaderServiceTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void plansOnlyAllowedLibrariesAndUsesOfficialArtifactMetadata(@TempDir Path root) throws Exception {
        FabricLoaderService service = service(root);
        JsonNode libraries = mapper.readTree("""
                [
                  {
                    "name": "net.fabricmc:fabric-loader:0.16.10",
                    "url": "https://maven.fabricmc.net/",
                    "downloads": {
                      "artifact": {
                        "path": "net/fabricmc/fabric-loader/0.16.10/fabric-loader-0.16.10.jar",
                        "url": "https://cdn.example.test/fabric-loader.jar",
                        "sha1": "0123456789012345678901234567890123456789",
                        "size": 1234
                      }
                    }
                  },
                  {
                    "name": "example:blocked:1.0",
                    "rules": [ { "action": "disallow" } ]
                  }
                ]
                """);

        List<FabricLoaderService.LibraryDownload> planned = service.planLibraries(libraries);

        assertThat(planned).singleElement().satisfies(download -> {
            DownloadService.DownloadRequest request = download.request();
            assertThat(download.name()).isEqualTo("net.fabricmc:fabric-loader:0.16.10");
            assertThat(request.candidates()).containsExactly(URI.create("https://cdn.example.test/fabric-loader.jar"));
            assertThat(request.destination()).isEqualTo(root.resolve("shared/libraries/net/fabricmc/fabric-loader/0.16.10/fabric-loader-0.16.10.jar"));
            assertThat(request.checksum()).isEqualTo("0123456789012345678901234567890123456789");
            assertThat(request.checksumAlgorithm()).isEqualTo(DownloadService.ChecksumAlgorithm.SHA_1);
            assertThat(request.expectedSize()).isEqualTo(1234);
        });
    }

    @Test
    void addsFabricMavenMirrorAndHonorsPreference(@TempDir Path root) throws Exception {
        JsonNode libraries = mapper.readTree("""
                [ { "name": "net.fabricmc:fabric-loader:0.16.10", "url": "https://maven.fabricmc.net/" } ]
                """);

        var officialFirst = service(root, false).planLibraries(libraries).getFirst().request().candidates();
        var mirrorFirst = service(root, true).planLibraries(libraries).getFirst().request().candidates();

        assertThat(officialFirst).containsExactly(
                URI.create("https://maven.fabricmc.net/net/fabricmc/fabric-loader/0.16.10/fabric-loader-0.16.10.jar"),
                URI.create("https://bmclapi2.bangbang93.com/maven/net/fabricmc/fabric-loader/0.16.10/fabric-loader-0.16.10.jar")
        );
        assertThat(mirrorFirst).containsExactly(officialFirst.get(1), officialFirst.get(0));
    }

    @Test
    void fallsBackToLibraryRepositoryAndMavenCoordinate(@TempDir Path root) throws Exception {
        FabricLoaderService service = service(root);
        JsonNode libraries = mapper.readTree("""
                [ { "name": "org.example:demo:2.0:natives-windows@zip", "url": "https://repo.example.test/maven" } ]
                """);

        DownloadService.DownloadRequest request = service.planLibraries(libraries).getFirst().request();

        assertThat(request.candidates()).containsExactly(URI.create(
                "https://repo.example.test/maven/org/example/demo/2.0/demo-2.0-natives-windows.zip"));
        assertThat(request.checksumAlgorithm()).isEqualTo(DownloadService.ChecksumAlgorithm.NONE);
    }

    private FabricLoaderService service(Path root) {
        return service(root, false);
    }

    private FabricLoaderService service(Path root, boolean preferMirror) {
        DownloadService downloads = (request, listener) -> CompletableFuture.completedFuture(request.destination());
        DownloadQueueService queue = new DownloadQueueService(downloads, root.resolve("queue.json"));
        Path instances = root.resolve("instances");
        Path shared = root.resolve("shared");
        VanillaGameService vanilla = new VanillaGameService(queue, instances, shared);
        return new FabricLoaderService(vanilla, queue, instances, shared, preferMirror);
    }
}
