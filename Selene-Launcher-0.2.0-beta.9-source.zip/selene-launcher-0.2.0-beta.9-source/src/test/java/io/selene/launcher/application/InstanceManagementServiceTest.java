package io.selene.launcher.application;

import io.selene.launcher.core.model.GameInstance;
import io.selene.launcher.core.model.InstanceSettings;
import io.selene.launcher.core.model.ManagedMod;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class InstanceManagementServiceTest {
    @Test
    void savesSettingsRenamesInstanceAndManagesMods(@TempDir Path root) throws Exception {
        Path instancesDirectory = root.resolve("instances");
        GameInstance instance = createInstance(instancesDirectory.resolve("fabric-test"));
        InstanceManagementService service = new InstanceManagementService(
                new VanillaGameService(null, instancesDirectory, root.resolve("shared"))
        );
        InstanceSettings settings = new InstanceSettings(
                1024, 6144, 1600, 900, true, "C:/Java/bin/javaw.exe",
                "-XX:+UseG1GC", "--demo", "play.example.com"
        );

        service.saveSettings(instance, settings);
        GameInstance renamed = service.rename(instance, "生存主实例");
        Path source = Files.writeString(root.resolve("example.jar"), "mod-content");
        service.importMod(renamed, source);

        assertThat(service.loadSettings(renamed)).isEqualTo(settings);
        assertThat(service.instances()).singleElement().satisfies(item -> assertThat(item.name()).isEqualTo("生存主实例"));
        assertThat(service.mods(renamed)).singleElement().satisfies(mod -> {
            assertThat(mod.fileName()).isEqualTo("example.jar");
            assertThat(mod.enabled()).isTrue();
        });

        ManagedMod disabled = service.setEnabled(service.mods(renamed).getFirst(), false);
        assertThat(disabled.path()).hasFileName("example.jar.disabled");
        assertThat(service.mods(renamed).getFirst().enabled()).isFalse();

        service.setEnabled(service.mods(renamed).getFirst(), true);
        service.deleteMod(service.mods(renamed).getFirst());
        assertThat(service.mods(renamed)).isEmpty();
    }

    @Test
    void onlyImportsJarFilesAndDeletesInsideInstanceRoot(@TempDir Path root) throws Exception {
        Path instancesDirectory = root.resolve("instances");
        GameInstance instance = createInstance(instancesDirectory.resolve("vanilla-test"));
        InstanceManagementService service = new InstanceManagementService(
                new VanillaGameService(null, instancesDirectory, root.resolve("shared"))
        );
        Path text = Files.writeString(root.resolve("not-a-mod.txt"), "x");

        assertThatThrownBy(() -> service.importMod(instance, text))
                .isInstanceOf(IllegalArgumentException.class)
                .hasMessage("只能导入 .jar 模组文件");

        service.delete(instance);
        assertThat(instance.directory()).doesNotExist();
    }

    private GameInstance createInstance(Path directory) throws Exception {
        Files.createDirectories(directory.resolve("game/mods"));
        GameInstance instance = new GameInstance(
                directory.getFileName().toString(), "测试实例", "1.21.1", directory,
                "net.minecraft.client.main.Main", 21, Instant.parse("2026-03-28T00:00:00Z")
        );
        Files.writeString(directory.resolve("instance.json"), """
                {
                  "schemaVersion": 2,
                  "id": "%s",
                  "name": "测试实例",
                  "versionId": "1.21.1",
                  "baseGameVersion": "1.21.1",
                  "directory": "%s",
                  "mainClass": "net.minecraft.client.main.Main",
                  "requiredJavaMajor": 21,
                  "installedAt": "2026-03-28T00:00:00Z",
                  "clientJar": "client.jar",
                  "assetIndex": "1.21",
                  "loader": "fabric"
                }
                """.formatted(instance.id(), directory.toString().replace("\\", "\\\\")));
        return instance;
    }
}
