package io.selene.launcher.infra;

import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import io.selene.launcher.core.model.GameVersion;
import io.selene.launcher.core.model.VersionCatalog;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.http.HttpClient;
import java.nio.charset.StandardCharsets;
import java.nio.file.Path;
import java.time.Clock;
import java.time.Instant;
import java.time.ZoneOffset;
import java.util.concurrent.CompletionException;
import java.util.concurrent.atomic.AtomicBoolean;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

class MojangVersionManifestProviderTest {
    private HttpServer server;

    @AfterEach
    void stopServer() {
        if (server != null) {
            server.stop(0);
        }
    }

    @Test
    void parsesOfficialShapeAndWritesCache(@TempDir Path directory) throws Exception {
        Instant now = Instant.parse("2026-03-27T12:00:00Z");
        server = startServer(exchange -> respond(exchange, 200, manifestJson(metadataUri("1.21.5"))));
        Path cache = directory.resolve("versions/version_manifest_v2.json");
        MojangVersionManifestProvider provider = provider(cache, now);

        VersionCatalog catalog = provider.fetchCatalog().join();

        assertThat(catalog.latestRelease()).isEqualTo("1.21.5");
        assertThat(catalog.latestSnapshot()).isEqualTo("26w13a");
        assertThat(catalog.origin()).isEqualTo(VersionCatalog.Origin.NETWORK);
        assertThat(catalog.fetchedAt()).isEqualTo(now);
        assertThat(catalog.versions()).hasSize(2);
        assertThat(catalog.versions().getFirst().type()).isEqualTo(GameVersion.Type.RELEASE);
        assertThat(cache).exists();
    }

    @Test
    void fallsBackToLastValidCacheWhenNetworkFails(@TempDir Path directory) throws Exception {
        AtomicBoolean available = new AtomicBoolean(true);
        server = startServer(exchange -> {
            if (available.get()) {
                respond(exchange, 200, manifestJson(metadataUri("1.21.5")));
            } else {
                respond(exchange, 503, "unavailable");
            }
        });
        Path cache = directory.resolve("manifest.json");
        MojangVersionManifestProvider provider = provider(cache, Instant.parse("2026-03-27T12:00:00Z"));
        assertThat(provider.fetchCatalog().join().origin()).isEqualTo(VersionCatalog.Origin.NETWORK);

        available.set(false);
        VersionCatalog cached = provider.fetchCatalog().join();

        assertThat(cached.origin()).isEqualTo(VersionCatalog.Origin.CACHE);
        assertThat(cached.latestRelease()).isEqualTo("1.21.5");
    }

    @Test
    void failsClearlyWhenNetworkAndCacheAreInvalid(@TempDir Path directory) throws Exception {
        server = startServer(exchange -> respond(exchange, 200, "{}"));
        MojangVersionManifestProvider provider = provider(
                directory.resolve("missing/manifest.json"),
                Instant.parse("2026-03-27T12:00:00Z")
        );

        assertThatThrownBy(() -> provider.fetchCatalog().join())
                .isInstanceOf(CompletionException.class)
                .hasCauseInstanceOf(MojangVersionManifestProvider.ManifestUnavailableException.class)
                .hasMessageContaining("no valid cache");
    }

    private MojangVersionManifestProvider provider(Path cache, Instant now) {
        return new MojangVersionManifestProvider(
                HttpClient.newHttpClient(),
                URI.create("http://127.0.0.1:" + server.getAddress().getPort() + "/manifest"),
                cache,
                Clock.fixed(now, ZoneOffset.UTC),
                true
        );
    }

    private URI metadataUri(String id) {
        return URI.create("http://127.0.0.1:" + server.getAddress().getPort() + "/versions/" + id + ".json");
    }

    private HttpServer startServer(ExchangeHandler handler) throws IOException {
        HttpServer result = HttpServer.create(new InetSocketAddress("127.0.0.1", 0), 0);
        result.createContext("/manifest", exchange -> {
            try {
                handler.handle(exchange);
            } finally {
                exchange.close();
            }
        });
        result.start();
        return result;
    }

    private String manifestJson(URI releaseMetadata) {
        String snapshotMetadata = releaseMetadata.resolve("../26w13a.json").toString();
        return """
                {
                  "latest": {"release": "1.21.5", "snapshot": "26w13a"},
                  "versions": [
                    {
                      "id": "1.21.5",
                      "type": "release",
                      "url": "%s",
                      "sha1": "1111111111111111111111111111111111111111",
                      "releaseTime": "2025-03-25T12:00:00Z",
                      "complianceLevel": 1
                    },
                    {
                      "id": "26w13a",
                      "type": "snapshot",
                      "url": "%s",
                      "sha1": "2222222222222222222222222222222222222222",
                      "releaseTime": "2026-03-25T12:00:00Z",
                      "complianceLevel": 1
                    }
                  ]
                }
                """.formatted(releaseMetadata, snapshotMetadata);
    }

    private static void respond(HttpExchange exchange, int status, String body) throws IOException {
        byte[] bytes = body.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=utf-8");
        exchange.sendResponseHeaders(status, bytes.length);
        exchange.getResponseBody().write(bytes);
    }

    @FunctionalInterface
    private interface ExchangeHandler {
        void handle(HttpExchange exchange) throws IOException;
    }
}
