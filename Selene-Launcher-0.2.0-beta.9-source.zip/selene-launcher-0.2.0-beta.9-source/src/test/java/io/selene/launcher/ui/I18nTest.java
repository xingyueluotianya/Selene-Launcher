package io.selene.launcher.ui;

import io.selene.launcher.core.model.AppLanguage;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicInteger;

import static org.assertj.core.api.Assertions.assertThat;

class I18nTest {
    @AfterEach
    void restoreEnglish() {
        I18n.setLanguage(AppLanguage.ENGLISH);
    }

    @Test
    void translatesStaticAndDynamicChineseTextToEnglish() {
        I18n.setLanguage(AppLanguage.ENGLISH);

        assertThat(I18n.text("游戏库")).isEqualTo("Game Library");
        assertThat(I18n.text("实例管理")).isEqualTo("Instances");
        assertThat(I18n.text("模组管理")).isEqualTo("Mod Management");
        assertThat(I18n.text("共 12 项 · 活动 2 · 暂停 1"))
                .isEqualTo("Total 12 items · Active 2 · Pause 1");
        assertThat(I18n.text("Selene Launcher")).isEqualTo("Selene Launcher");
    }

    @Test
    void translatesEnglishInterfaceTextBackToSimplifiedChinese() {
        I18n.setLanguage(AppLanguage.SIMPLIFIED_CHINESE);

        assertThat(I18n.text("Resource Center")).isEqualTo("资源中心");
        assertThat(I18n.text("Instances")).isEqualTo("实例管理");
        assertThat(I18n.text("Selene Launcher")).isEqualTo("Selene Launcher");
    }

    @Test
    void notifiesListenersOnlyWhenLanguageActuallyChanges() throws Exception {
        I18n.setLanguage(AppLanguage.ENGLISH);
        AtomicInteger changes = new AtomicInteger();

        try (AutoCloseable ignored = I18n.onChange(changes::incrementAndGet)) {
            I18n.setLanguage(AppLanguage.ENGLISH);
            I18n.setLanguage(AppLanguage.SIMPLIFIED_CHINESE);
        }

        assertThat(changes).hasValue(1);
    }
}
