package io.selene.launcher.application;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.selene.launcher.core.port.DownloadService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.concurrent.CompletableFuture;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

import static org.assertj.core.api.Assertions.assertThat;

class InstallerLoaderServiceTest {
    private final ObjectMapper mapper = new ObjectMapper();

    @Test
    void readsOfficialVersionIdentityFromInstallerArchive(@TempDir Path root) throws Exception {
        Path installer = root.resolve("forge-installer.jar");
        try (ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(installer))) {
            write(output, "install_profile.json", """
                    { "minecraft": "1.21.1", "version": "1.21.1-forge-52.1.14" }
                    """);
            write(output, "version.json", """
                    { "id": "1.21.1-forge-52.1.14", "inheritsFrom": "1.21.1" }
                    """);
        }

        InstallerLoaderService.InstallerProfile profile = service(root).readInstallerProfile(installer);

        assertThat(profile.versionId()).isEqualTo("1.21.1-forge-52.1.14");
        assertThat(profile.minecraftVersion()).isEqualTo("1.21.1");
    }

    @Test
    void plansInstallerLibrariesFromBothProfilesWithMirrorFallback(@TempDir Path root) throws Exception {
        Path installer = root.resolve("neoforge-installer.jar");
        try (ZipOutputStream output = new ZipOutputStream(Files.newOutputStream(installer))) {
            write(output, "install_profile.json", """
                    { "libraries": [ {
                      "name": "net.neoforged.installertools:installertools:2.1.2",
                      "downloads": { "artifact": {
                        "path": "net/neoforged/installertools/installertools/2.1.2/installertools-2.1.2.jar",
                        "url": "https://maven.neoforged.net/releases/net/neoforged/installertools/installertools/2.1.2/installertools-2.1.2.jar",
                        "sha1": "0123456789012345678901234567890123456789", "size": 456
                      } }
                    } ] }
                    """);
            write(output, "version.json", """
                    { "libraries": [ {
                      "name": "net.neoforged:neoforge:21.1.191:universal",
                      "url": "https://maven.neoforged.net/releases/"
                    } ] }
                    """);
        }

        var libraries = service(root, true).planInstallerLibraries(
                InstallerLoaderService.Loader.NEOFORGE, installer);

        assertThat(libraries).hasSize(2);
        assertThat(libraries.getFirst().request().candidates()).extracting(Object::toString).containsExactly(
                "https://bmclapi2.bangbang93.com/maven/net/neoforged/installertools/installertools/2.1.2/installertools-2.1.2.jar",
                "https://maven.neoforged.net/releases/net/neoforged/installertools/installertools/2.1.2/installertools-2.1.2.jar"
        );
        assertThat(libraries.get(1).request().destination()).isEqualTo(root.resolve(
                "shared/libraries/net/neoforged/neoforge/21.1.191/neoforge-21.1.191-universal.jar"));
    }

    @Test
    void preparesMinimalLauncherProfileWithoutLosingExistingProfiles(@TempDir Path root) throws Exception {
        Path shared = root.resolve("shared");
        Files.createDirectories(shared);
        Files.writeString(shared.resolve("launcher_profiles.json"), """
                { "profiles": { "existing": { "name": "现有配置" } }, "clientToken": "abc" }
                """);

        service(root).prepareInstallerDirectory();

        JsonNode profile = mapper.readTree(shared.resolve("launcher_profiles.json").toFile());
        assertThat(profile.path("profiles").path("existing").path("name").asText()).isEqualTo("现有配置");
        assertThat(profile.path("clientToken").asText()).isEqualTo("abc");
        assertThat(shared.resolve("versions")).isDirectory();
        assertThat(shared.resolve("libraries")).isDirectory();
    }

    @Test
    void mapsForgeAndNeoForgePublishedVersionsAndInstallerUrls() {
        assertThat(InstallerLoaderService.Loader.FORGE.selectableVersion("1.20.1", "1.20.1-47.4.0"))
                .isEqualTo("47.4.0");
        assertThat(InstallerLoaderService.Loader.FORGE.installerUri("1.20.1", "47.4.0").toString())
                .endsWith("/1.20.1-47.4.0/forge-1.20.1-47.4.0-installer.jar");
        assertThat(InstallerLoaderService.Loader.NEOFORGE.selectableVersion("1.21.1", "21.1.191"))
                .isEqualTo("21.1.191");
        assertThat(InstallerLoaderService.Loader.NEOFORGE.selectableVersion("1.21", "21.0.167"))
                .isEqualTo("21.0.167");
        assertThat(InstallerLoaderService.Loader.NEOFORGE.selectableVersion("1.21", "21.1.191"))
                .isNull();
        assertThat(InstallerLoaderService.Loader.NEOFORGE.selectableVersion("1.21.1", "21.11.38-beta"))
                .isNull();
        assertThat(InstallerLoaderService.Loader.NEOFORGE.installerUri("1.21.1", "21.1.191").toString())
                .endsWith("/21.1.191/neoforge-21.1.191-installer.jar");
    }

    @Test
    void ordersNeoForgeOfficialAndMirrorSourcesByPreference() {
        var officialFirst = InstallerLoaderService.Loader.NEOFORGE
                .installerUris("1.21.1", "21.1.191", false);
        var mirrorFirst = InstallerLoaderService.Loader.NEOFORGE
                .installerUris("1.21.1", "21.1.191", true);

        assertThat(officialFirst).extracting(Object::toString).containsExactly(
                "https://maven.neoforged.net/releases/net/neoforged/neoforge/21.1.191/neoforge-21.1.191-installer.jar",
                "https://bmclapi2.bangbang93.com/maven/net/neoforged/neoforge/21.1.191/neoforge-21.1.191-installer.jar"
        );
        assertThat(mirrorFirst).containsExactly(officialFirst.get(1), officialFirst.get(0));
        assertThat(InstallerLoaderService.Loader.NEOFORGE.metadataUris(true).getFirst().getHost())
                .isEqualTo("bmclapi2.bangbang93.com");
    }

    private InstallerLoaderService service(Path root) {
        return service(root, false);
    }

    private InstallerLoaderService service(Path root, boolean preferMirror) {
        DownloadService downloads = (request, listener) -> CompletableFuture.completedFuture(request.destination());
        DownloadQueueService queue = new DownloadQueueService(downloads, root.resolve("queue.json"));
        Path shared = root.resolve("shared");
        VanillaGameService vanilla = new VanillaGameService(queue, root.resolve("instances"), shared);
        return new InstallerLoaderService(vanilla, queue, root.resolve("instances"), shared,
                root.resolve("tools"), requiredJava -> CompletableFuture.failedFuture(new AssertionError("不应请求 Java")),
                preferMirror);
    }

    private void write(ZipOutputStream output, String name, String value) throws Exception {
        output.putNextEntry(new ZipEntry(name));
        output.write(value.getBytes(StandardCharsets.UTF_8));
        output.closeEntry();
    }
}
