package io.selene.launcher.infra;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;

import java.nio.file.Files;
import java.nio.file.Path;

import static org.assertj.core.api.Assertions.assertThat;

class LocalCredentialVaultTest {
    @Test
    void encryptsAndRestoresCredential(@TempDir Path directory) throws Exception {
        LocalCredentialVault vault = new LocalCredentialVault(directory.resolve("credential.key"));

        String encrypted = vault.seal("secret-access-token");

        assertThat(encrypted).startsWith("v1:").doesNotContain("secret-access-token");
        assertThat(vault.open(encrypted)).isEqualTo("secret-access-token");
        assertThat(Files.size(directory.resolve("credential.key"))).isEqualTo(32);
    }
}
