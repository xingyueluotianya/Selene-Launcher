rootProject.name = "selene-launcher"
